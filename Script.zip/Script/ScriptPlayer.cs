﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScriptPlayer : MonoBehaviour {

	public Camera camera;
	public float limiteCamEsquerda, limiteCamDireita;
	public float velocidade;
	public float impulso; 


	public Transform sensorChao;
	bool estaNoChao;


	public Text countText;
	public Text especialText;
	public Text winEspecialText;
	public Text winText;
	public Text wowText;
	public Text msgInicioText;
	public Text inicioEstrelas;


	//public bool mudarCena; // novo


	public AudioSource audioImpulso;
	public AudioSource audioBatida;
	public AudioSource audioItem;
	public AudioSource audioItemB;
	public AudioSource audioFlipA;
	public AudioSource audioFlipB;
	public AudioSource audioItemC;
	public AudioSource audioVitoria;
	public AudioSource audioVitoria2;
	public AudioSource audioVitoria3;
	public AudioSource audioTrilha;
	public AudioSource audioTiroGreen;
	public AudioSource audioLoadScene;


	// modo tiro ativo
	public GameObject tiroGreen;
	public GameObject trailRender;
	public Transform mira;
	public Transform ancoraMira;
	public Transform ancoraTrail;


	// contagem score, cubos

	private int count;
	private int especial;
	private int win;
	private bool cena;
	private bool trilha;
	private int inicio;
	private bool vitoria;

	private bool soundBg;

	//private bool cena; 

	public static bool hit;



	SpriteRenderer sr;
	Rigidbody2D rb2d;
	Collider2D cl;

	//Text txt;

	Vector2 posicaoInicial;


	// Use this for initialization
	void Start () {

		rb2d = GetComponent <Rigidbody2D> ();
		sr = GetComponent <SpriteRenderer> ();
		cl = GetComponent <Collider2D> ();

	
		//txt = GetComponent <Text> ();
	
		soundBg = true;
		trilha = true;
		vitoria = true;
		cena = true;
		count = 0;
		especial = 0;
		inicio = 0;
		win = 0;

		SetCountText ();
		SetEspecialText ();
		wowText.text = " ";
		winEspecialText.text = " ";

		inicioEstrelas.enabled = false;
		winText.enabled = false;



		posicaoInicial = transform.position;
		transform.position = new Vector2 (-21.0f, 0.40f);


		
	}
	
	// Update is called once per frame
	void Update () {
		//nave no chao/nao chao 
		estaNoChao = Physics2D.Linecast(transform.position, sensorChao.position, 1 << LayerMask.NameToLayer ("Chao"));


		// movimento direcional personagem
		float moverX = Input.GetAxisRaw  ("Horizontal") * velocidade * Time.deltaTime;
		transform.Translate (moverX, 0.0f, 0.0f);

		/*
		 * // input para d-pad -- esses inputs so funcionaram corretamente se calibrar a camera  = estao quase funbcionando
		if (Input.GetButtonDown ("D-Pad Horizontal")){
		transform.Translate (velocidade, 0.0f, 0.0f);
		}

		*/


		//pulo personagem
		if (Input.GetButtonDown ("Jump")) {
			rb2d.velocity = new Vector2 (0.0f, impulso);
			audioImpulso.Play();
		}

	

		

		//flip Green e aliado

		if (Input.GetAxisRaw ("Horizontal") > 0) {
			sr.flipX = false;
			audioFlipA.Play ();
			ancoraMira.transform.eulerAngles = new Vector2 (0.0f, 0.0f); 

			ancoraTrail.transform.eulerAngles = new Vector2 (0.0f, 0.0f);
		}else if (Input.GetAxisRaw ("Horizontal") < 0){
			sr.flipX = true;
			audioFlipB.Play ();
			ancoraMira.transform.eulerAngles = new Vector2 (0.0f, 180f); 

			ancoraTrail.transform.eulerAngles = new Vector2 (0.0f, 180f);
		}


		/*
		 * //flip com d-pad

		if (Input.GetButton ("D-pad Horizontal")) {
			sr.flipX = false;
			audioFlipA.Play ();
			ancoraMira.transform.eulerAngles = new Vector2 (0.0f, 0.0f); 

			ancoraTrail.transform.eulerAngles = new Vector2 (0.0f, 0.0f);
		}else if (Input.GetButton ("D-pad Horizontal")){
			sr.flipX = true;
			audioFlipB.Play ();
			ancoraMira.transform.eulerAngles = new Vector2 (0.0f, 180f); 

			ancoraTrail.transform.eulerAngles = new Vector2 (0.0f, 180f);
		}

		*/


		// tiro de Green quando no modo tiro -- apos liberar Boss
		//if (Input.GetButtonDown("Fire1")) {
			//Instantiate (tiroGreen, mira.transform.position, mira.transform.rotation);
			//audioTiroGreen.Play ();
		//}
	


		// Camera

		camera.transform.position = new Vector3 (transform.position.x, camera.transform.position.y, camera.transform.position.z);
	


		// prepara as courotines dos textos de status

		if (count == 200 && winText) {
			StartCoroutine (ApagarTexto ());
		} else if (especial == 800 && winEspecialText) {
			StartCoroutine (ApagarTextoEspecial ());
		} else if (inicio == 10 && msgInicioText) {
			StartCoroutine (ApagarInicioTexto ());
		}
		/*else if (wowText) { // novo
			StartCoroutine (MudarCena ()); // novo
		} */

	
	}


	// colisoes por trigger com itens

	void OnTriggerEnter2D(Collider2D estrelas) {
		if (estrelas.gameObject.CompareTag ("Estrela")) {
			estrelas.gameObject.SetActive (false);
			count = count + 1;
			audioItem.Play ();
			SetCountText ();
		} else if (estrelas.gameObject.CompareTag ("EstrelaB")) {
			estrelas.gameObject.SetActive (false);
			count = count + 3;
			audioItemB.Play ();
			SetCountText ();
		} else if (estrelas.gameObject.CompareTag ("Especial")) {
			estrelas.gameObject.SetActive (false);
			especial = especial + 100;
			audioItemC.Play ();
			SetEspecialText ();
			//seta a entrada do audio no fim da level
		} else if (estrelas.gameObject.CompareTag ("Trilha")) {
			estrelas.gameObject.SetActive (true);
			trilha = trilha;
			audioTrilha.Play (); 
			print ("oi");
			
		} else if (estrelas.gameObject.CompareTag ("Estrela")) {
			estrelas.gameObject.SetActive (true);
			count = inicio;
			print ("oi");
		
		} else if (estrelas.gameObject.CompareTag ("LoadScene")) {
			estrelas.gameObject.SetActive (true);
			cena = cena;
			audioLoadScene.Play (); 
			print ("oi");
			SceneManager.LoadScene ("BossFinalScript");

		} else if (estrelas.gameObject.CompareTag ("Estrela")) {
			estrelas.gameObject.SetActive (false);
			win = win;
			//audioVitoria.Play ();
			SetCountText ();
		} else if (estrelas.gameObject.CompareTag ("Vitoria")) {
			estrelas.gameObject.SetActive (true);
			vitoria = vitoria;
			audioVitoria3.Play (); 
			print ("oi");
		}

		if (count == 10) {
		
			inicioEstrelas.enabled = true;
			audioVitoria2.Play (); // esse audio nao toca!!!
			StartCoroutine (EsperarTextoInicio ());
		} else if (count == 200) {
			audioVitoria3.Play ();
			winText.enabled = true;
			StartCoroutine (EsperarTextoWin ());

		}
	}


	void SetCountText(){
		countText.text = " " + count.ToString ();
		//if (count == 2) {
			//audioVitoria2.Play ();
		 

		//winText.text = "— Continue!"; //setar os segundos em que essa mensagem deve ficar na tela

			// como deixar apenas 5 segundos essa frase? E IR PRA TELA QUE DUELA COMO O BOSS? QUE É A CONTINUIDADE DE ONDE ELE ESTA
	}

		void SetEspecialText(){
		especialText.text = "  " + especial.ToString ();
		if (especial == 800) {
		audioVitoria3.Play ();
		//winEspecialText.text = "— Você cumpriu parte de sua missão!";
		
		}

	} 

		// COMO COMPUTAR UM VALOR MENOR NO FIM, CASO O PLAYER NAO TENHA APANHADO TODOS OS PONTOS, no fim do percurso? usando time?	





		
	void OnCollisionEnter2D(Collision2D c){
			if(c.collider .tag == "Danger"){
			audioBatida.Play ();
			wowText.text = "— WOW!";
			cl.enabled = false;
			sr.enabled = false;
			StartCoroutine (EperarGameOver ());
		
		}//if (c.collider.tag == "DangerA") {
		//	audioBatida.Play ();
		//	Destroy (gameObject);
		//	wowText.text = "— WOW!";
		//	SceneManager.LoadScene ("TenteOutravez");

		//}
	}

	// courotine do texto ccriada em linha 128 

	IEnumerator ApagarTexto(){
		winText.enabled = hit;
		winText.text = "— You collected 200 stars!"; // nao consigo fazer essa courotine funcionar
		//audioVitoria.Play ();
		hit = true;
		yield return new WaitForSeconds (7.0f);
		hit = false;
	}

	IEnumerator ApagarTextoEspecial(){
		winEspecialText.enabled = hit;
		winEspecialText.text = "— GO Ahead! To the next plataform, now!";
		audioVitoria.Play ();
		hit = true;
		yield return new WaitForSeconds (5.0f);
		hit = false;
	
	}

	IEnumerator ApagarInicioTexto(){ // essa tb nao funciona!!!
		msgInicioText.enabled = hit;
		msgInicioText.text = "— Don't forget the your stars!";
		hit = true;
		yield return new WaitForSeconds (5.0f);
		hit = false;
	}

	IEnumerator EsperarTextoInicio(){
		yield return new WaitForSeconds (4.0f);
		inicioEstrelas.enabled = false;
	}

	IEnumerator EsperarTextoWin(){
		audioVitoria2.Play ();
		yield return new WaitForSeconds (4.0f);
		Destroy (winText);
	}

	IEnumerator EperarGameOver(){
		yield return new WaitForSeconds (1.0f);
		SceneManager.LoadScene ("TenteOutravez");
	}
}
