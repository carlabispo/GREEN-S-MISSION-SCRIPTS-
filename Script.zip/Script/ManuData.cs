﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManuData : MonoBehaviour {

	public static int record;
	private GameObject[] datas;

	// Use this for initialization
	void Awake () {
		datas = GameObject.FindGameObjectsWithTag ("Data");	
	}

}
