﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneNovoA : MonoBehaviour {

	public string cena;
	public AudioSource audioC;

		


	void Update(){
	
		if (Input.GetKey("escape")){
			audioC.Play ();
			SceneManager.LoadScene (cena);
		} 	
	
	}
}