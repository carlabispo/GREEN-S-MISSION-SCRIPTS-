﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SerraScript : MonoBehaviour {


		//public GameObject Serra;
		//public float posicaoInicial;
		//public float posicaoFinal;
		public float posicaoDestruir;
		public float intervaloDestruir;
		//public float limiteTop, limiteBotton;

		public float velocidade;
		//public float intervalo;


		// Use this for initialization
		void Start () {
			StartCoroutine (Destruir (intervaloDestruir));
		}

		// Update is called once per frame
		void Update () {

		transform.Translate (Vector2.left * velocidade * Time.deltaTime); 

			if (transform.position.x < posicaoDestruir) {
				Destroy (gameObject);
			
			}


		}

	IEnumerator Destruir (float i){
		yield return new WaitForSeconds (i);
		Destroy (gameObject);
	}

		/*IEnumerator Gerar (float t){
		Vector3 p = new Vector3 (Random.Range (limiteTop, limiteBotton), 4.0f, -2.0f);
		Instantiate (miniNave, p, miniNave.transform.rotation);
		yield return new WaitForSeconds (t);
		StartCoroutine (Gerar (intervalo));
	}*/

	}
