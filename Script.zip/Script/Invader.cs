﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Invader : MonoBehaviour {

	public GameObject alvo;
	public float pontoDeAlcance;
	public Transform miraBoss;
	public GameObject projetilBoss;

	public Text txtVida;

	public static int vida;
	public static bool hit;

	bool atacando;

	// Use this for initialization
	void Start () {
		vida = 3;
		txtVida.text = vida.ToString ();
		txtVida.enabled = hit;

	}
	
	// Update is called once per frame
	void Update () {
		if (hit) {
			StartCoroutine (MostrarVida ());
		}

		float D = Vector2.Distance (transform.position, alvo.transform.position);

		if (D < pontoDeAlcance && !atacando) {
			//StartCoroutine  (Alcancar ());
		}
	}

	IEnumerator MostrarVida(){
		txtVida.enabled = hit;
		txtVida.text = vida.ToString();
		hit = false;
		yield return new WaitForSeconds (0.5f);
		txtVida.enabled = hit;
	}


	IEnumerator Ataque(){
		atacando = true;
		Instantiate (projetilBoss, miraBoss.position, miraBoss.rotation);
		yield return new WaitForSeconds (0.2f);

	}

}
