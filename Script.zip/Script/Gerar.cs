﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gerar : MonoBehaviour {

	public GameObject objeto;
	public float intervalo;
	public float posicaoSpawn;
	public float altura;





	// Use this for initialization
	void Start () {

		StartCoroutine (Criar (intervalo));

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	IEnumerator Criar (float t){



		Vector2 p = new Vector2 (posicaoSpawn, altura);

	


		Instantiate (objeto, p, objeto.transform.rotation);
		yield return new WaitForSeconds (t);
		StartCoroutine (Criar(intervalo));





	}

}
