﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class particulaScript : MonoBehaviour {

	float velocidade;

	SpriteRenderer sr3;



	// Use this for initialization
	void Start () {

		sr3 = GetComponent <SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetAxis ("Horizontal")< 0) {
			sr3.flipX = true;
		
		} else if (Input.GetAxis ("Horizontal") > 0) {
			sr3.flipX = false;
		}
		
	}
}
