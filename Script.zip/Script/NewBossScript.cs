﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class NewBossScript : MonoBehaviour {

	public float velocidade;
	public float posicaoDestruir;
	public float intervaloDestruir;





	//public float campoDeVisao;
	//public Transform mira;
	//public GameObject projetil;

	public AudioSource audioDanoBoss;
	//public Text huuText; 

	//public static int vida;
	//public static bool hit;

	//private bool duelando;


	// Use this for initialization
	void Start () {

		StartCoroutine (Destruir (intervaloDestruir));

	


		//vida = 5;
		//huuText.text = " ";

		
	}
	
	// Update is called once per frame
	void Update () {

		transform.Translate (Vector2.left * velocidade * Time.deltaTime);
		if (transform.position.x < posicaoDestruir) {
			Destroy (gameObject);

		}
		
	}

	void OnCollisonEnter2D(Collision2D c){
		
		if (c.collider.tag == "Projetil") {
			audioDanoBoss.Play ();
			print ("colidindo");
			Destroy (gameObject);
		}
			
	
	}

	IEnumerator Destruir (float i){
		yield return new WaitForSeconds (i);
		Destroy (gameObject);
	}


		
}