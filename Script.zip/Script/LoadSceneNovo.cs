﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneNovo : MonoBehaviour {

	public string cena;
	public AudioSource audioC;

		


	void Update(){
	
		if (Input.GetButtonDown("Jump")){
			audioC.Play ();
			SceneManager.LoadScene (cena);
		} 	
	
	}
}