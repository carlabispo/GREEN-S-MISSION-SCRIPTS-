﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScriptPlayerDuelo : MonoBehaviour {

	public Camera camera;
	public float limiteCamEsquerda, limiteCamDireita;
	public float velocidade;
	public float velocidadeA;
	public float impulso; 



	public Text wowText;





	public Transform sensorChao;

	bool estaNoChao;

	SpriteRenderer sr;
	Rigidbody2D rb2d;
	Collider2D cl;

	//audios
	public AudioSource audioImpulso;
	public AudioSource audioFlipA;
	public AudioSource audioFlipB;
	public AudioSource audioTiroGreen;
	public AudioSource audioLoadScene;
	public AudioSource audioBatidaSerra;
	public AudioSource audioVitoria;
	public AudioSource audioVitoria3;


	//setup tiro green

	public GameObject tiroGreen2;
	public GameObject trailRender;
	public Transform mira;
	public Transform ancoraMira;
	public Transform ancoraTrail;


	private bool cena;
	private bool vitoria;




	// Use this for initialization
	void Start () {
		
		rb2d = GetComponent <Rigidbody2D> ();
		sr = GetComponent <SpriteRenderer> ();

		cena = true;
		vitoria = true;


		wowText.text = " ";
	




		
	}
	
	// Update is called once per frame
	void Update () {

		//nave no chao/nao chao 
		estaNoChao = Physics2D.Linecast(transform.position, sensorChao.position, 1 << LayerMask.NameToLayer ("Chao"));


		// movimento direcional personagem
		float moverX = Input.GetAxisRaw ("Horizontal") * velocidade * Time.deltaTime;
		transform.Translate (moverX, 0.0f, 0.0f);

		float moverY = Input.GetAxisRaw ("Vertical") * velocidadeA * Time.deltaTime;
		transform.Translate (0.0f, moverY, 0.0f);



		//pulo personagem
		if (Input.GetButtonDown ("Jump")) {
			rb2d.velocity = new Vector2 (0.0f, impulso);
			audioImpulso.Play();
		}

		//flip Green e aliado

		if (Input.GetAxisRaw ("Horizontal") > 0) {
			sr.flipX = false;
			audioFlipA.Play ();
			ancoraMira.transform.eulerAngles = new Vector3 (0.0f, 0.0f, 0.0f); 


			ancoraTrail.transform.eulerAngles = new Vector3 (0.0f, 0.0f, 0.0f);
		}else if (Input.GetAxisRaw ("Horizontal") < 0){
			sr.flipX = true;
			audioFlipB.Play ();
			ancoraMira.transform.eulerAngles = new Vector3 (0.0f, 180f, 0.0f);


			ancoraTrail.transform.eulerAngles = new Vector3 (0.0f, 180f, 0.0f);
		}


		// tiro de Green quando no modo tiro -- apos liberar Boss
		if (Input.GetButtonDown ("Fire1")) {
			Instantiate (tiroGreen2, mira.transform.position, mira.transform.rotation);
			audioTiroGreen.Play ();

		}



		//camera

		camera.transform.position = new Vector3 (transform.position.x, camera.transform.position.y, camera.transform.position.z);

		}

	void OnTriggerEnter2D(Collider2D estrelas) {



		if (estrelas.gameObject.CompareTag ("LoadScene")) {
			estrelas.gameObject.SetActive (true);
			cena = cena;
			audioLoadScene.Play (); 
			print ("oi");
			SceneManager.LoadScene ("Scene_b");


		} else if (estrelas.gameObject.CompareTag ("efeito")) {
			estrelas.gameObject.SetActive (true);
			cena = cena;
			audioLoadScene.Play (); 
			print ("oi");

		} else if (estrelas.gameObject.CompareTag ("Vitoria")) {
			estrelas.gameObject.SetActive (true);
			vitoria = vitoria;
			audioVitoria.Play (); 
			print ("oi");
			//SceneManager.LoadScene ("Vitoria");
		
		} else if (estrelas.gameObject.CompareTag ("Vitoria")) {
			estrelas.gameObject.SetActive (true);
			vitoria = vitoria;
			audioVitoria3.Play (); 
			print ("oi");
			//SceneManager.LoadScene ("Vitoria");


		} else if (estrelas.gameObject.CompareTag ("Vitoria2")) {
			estrelas.gameObject.SetActive (true);
			vitoria = vitoria;
			//audioVitoria3.Play (); 
			print ("oi");
			SceneManager.LoadScene ("Vitoria");
		}



	}




	void OnCollisionEnter2D(Collision2D c){
		
		if (c.collider.tag == "Danger") {
			audioBatidaSerra.Play ();
			Destroy (gameObject);
			wowText.text = "— WOW!";
			//StartCoroutine (MudarCena ());
			SceneManager.LoadScene ("TenteNovamente");

		} else if (c.collider.tag == "Inimigo") {
			audioBatidaSerra.Play ();
			Destroy (gameObject);
			wowText.text = "— WOW!";
			SceneManager.LoadScene ("TenteNovamente");

		} else if (c.collider.tag == "InimigoA") {
			audioBatidaSerra.Play ();
			Destroy (gameObject);
			wowText.text = "— WOW!";
			SceneManager.LoadScene ("TenteNovamente");
		} 


	}
		

}


