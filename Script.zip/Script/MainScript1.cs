﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainScript1 : MonoBehaviour {


	static public int scoreA;



	public Text scs;




	// Use this for initialization
	void Start () {

		scoreA = 0;

	
	}

	// Update is called once per frame
	void Update () {
		scs.text = "  " + scoreA.ToString();

	}
}
