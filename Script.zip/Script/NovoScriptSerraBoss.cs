﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NovoScriptSerraBoss : MonoBehaviour {


	//public GameObject Serra;
	//public float posicaoInicial;
	//public float posicaoFinal;
	public float posicaoDestruir;
	public float intervaloDestruir;
	public AudioSource audioDanoSerra;
	public AudioSource audioDanoFim;

	//public float limiteTop, limiteBotton;

	public float velocidade;
	//public float intervalo;

	static public int change;
	public Text ch;

	// Use this for initialization
	void Start () {

		change = 10;

		StartCoroutine (Destruir (intervaloDestruir)); // para destruir o objeto automaticamente em caso de nao ser atingido por projetil
	}

	// Update is called once per frame
	void Update () {

		ch.text = "CHANGE: " + change.ToString(); //nao aparece pq nao estou usando

		transform.Translate (Vector2.left * velocidade * Time.deltaTime); 
		if (transform.position.x < posicaoDestruir) {
			Destroy (gameObject);
		}

		if (NovoScriptSerraBoss.change <= 0){

			audioDanoFim.Play ();
			//SceneManager.LoadScene ("GameOver");
			//StartCoroutine(GameOver ());
			Destroy (gameObject);
		}
	}

	void OnCollisionEnter2D(Collision2D c){

		if (c.collider.tag == "Projetil") {
					audioDanoSerra.Play ();
					change -= 1;
					print ("OLA");
				}
			

		}
		
	
	IEnumerator Destruir (float i){
		yield return new WaitForSeconds (i);
		Destroy (gameObject);
		}


	}
	