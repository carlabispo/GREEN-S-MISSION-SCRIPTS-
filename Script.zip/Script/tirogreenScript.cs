﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tirogreenScript : MonoBehaviour {

	public float velocidade;

	// Use this for initialization
	void Start () {

		Destroy (gameObject, 0.5f);
			
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (Vector2.right * velocidade * Time.deltaTime);
		
	}

	void OnCollisionEnter2D(Collision2D c){


		if (c.gameObject.tag == "Inimigo") {
			Destroy (c.gameObject);			
			//Destroy (gameObject);
		}



	}
}
