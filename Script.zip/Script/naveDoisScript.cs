﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class naveDoisScript : MonoBehaviour {

	//float velocidade;
	public GameObject trailRenderer2;
	public Transform ancoraTrail2;

	//public static bool hit;
	//float impulso;

	public Transform mTarget;
	//float mSpeed = 10.0f;

	//Vector2 mLookDirection;

	//const float EPSILON =10.0f;

	SpriteRenderer sr2;
	Collider2D cl2d;



	//Rigidbody2D rb2d;


	// Use this for initialization
	void Start () {

		sr2 = GetComponent <SpriteRenderer> ();
		//rb2d = GetComponent <> (Rigidbody2D);
		
	}
	
	// Update is called once per frame
	void Update () {

		//mLookDirection = (mTarget.position - transform.position).normalized;

		//if ((transform.position - mTarget.position).magnitude > EPSILON) {
		
			//transform.Translate (mLookDirection * Time.deltaTime * mSpeed);	
		//}

		//if (Input.GetButtonDown ("Fire1")) {
			//rb2d = new Vector2 (0.0f, impulso);
		//}


		
		if (Input.GetAxis ("Horizontal") < 0) {
			sr2.flipX = true;
			ancoraTrail2.transform.eulerAngles = new Vector2 (0.0f, 0.0f);

		} else if (Input.GetAxis ("Horizontal") > 0) {
			sr2.flipX = false;
			ancoraTrail2.transform.eulerAngles = new Vector2 (0.0f, 180f);

		}

	}

	void DesligarBilly(){
		if  (mTarget is SpriteRenderer == false);
		sr2.enabled = false;
		cl2d.enabled = false;
			
		}
		
	}




